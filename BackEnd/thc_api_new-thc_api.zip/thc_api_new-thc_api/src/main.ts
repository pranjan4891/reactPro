import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { WinstonLoggerService } from './logger/winston-logger.service';
import { HttpExceptionFilter } from './logger/http-exception.filter';
import { BadRequestException, ValidationPipe } from '@nestjs/common';
import { ValidationError } from 'class-validator';
import { ResponseInterceptor } from './interceptors/response.interceptor';
import { GlobalExceptionFilter } from './filters/global-exception.filter';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Set global API prefix
  app.setGlobalPrefix('api');

  // Enable CORS
  app.enableCors();

  // Set Logger ---
  const logger = app.get(WinstonLoggerService);
  app.useLogger(logger);

  // Use global filters for exceptions
  app.useGlobalFilters(new HttpExceptionFilter(logger));
  app.useGlobalFilters(new GlobalExceptionFilter());

  // Apply global response interceptor
  app.useGlobalInterceptors(new ResponseInterceptor());

  // Customize ValidationPipe to format error responses as key-value pairs
  app.useGlobalPipes(
    new ValidationPipe({
      transform: true,
      whitelist: true,
      forbidNonWhitelisted: true,
      exceptionFactory: (validationErrors: ValidationError[] = []) => {
        // Reduce validation errors into a key-value pair format
        const errors = validationErrors.reduce((acc, error) => {
          const constraints = Object.values(error.constraints || {});
          acc[error.property] = constraints;
          return acc;
        }, {});

        // Throw a BadRequestException with the formatted errors
        return new BadRequestException({
          success: false,
          data: null,
          exceptions: null,
          httpStatusCode: 400,
          errors,
        });
      },
    }),
  );

  await app.listen(8000);
}
bootstrap();
