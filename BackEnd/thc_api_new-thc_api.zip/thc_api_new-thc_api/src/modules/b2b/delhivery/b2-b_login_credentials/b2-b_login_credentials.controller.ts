import { Body, Controller, Get, HttpStatus, Post, Res } from '@nestjs/common';
import { B2BLoginCredentialsService } from './b2-b_login_credentials.service';
import { Response } from 'express';

@Controller('b2b-login-credentials')
export class B2BLoginCredentialsController {
  constructor(private readonly B2BLoginService: B2BLoginCredentialsService) {}

  // Endpoint to manually trigger login
  @Post('Delhiverylogin')
  async login(@Res() res: Response) {
    try {
      const token = await this.B2BLoginService.delhiveryLogin();
      return res.status(200).json({ token });
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  }
}
