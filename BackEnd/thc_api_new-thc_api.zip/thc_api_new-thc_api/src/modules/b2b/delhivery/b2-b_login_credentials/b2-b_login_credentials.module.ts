import { Module } from '@nestjs/common';
import { B2BLoginCredentialsController } from './b2-b_login_credentials.controller';
import { B2BLoginCredentialsService } from './b2-b_login_credentials.service';

@Module({
  controllers: [B2BLoginCredentialsController],
  providers: [B2BLoginCredentialsService]
})
export class B2BLoginCredentialsModule {}
