import { Injectable } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import axios from 'axios';
import { ConfigService } from '@nestjs/config';
import { saveToEnv } from '../../../../helper/envUtils';
import { API_URL } from 'src/util/constants';

@Injectable()
export class B2BLoginCredentialsService {
  private token: string | null = null;

  constructor(private configService: ConfigService) {}

  // Manual login function
  async delhiveryLogin(): Promise<string | null> {
    try {
      const response = await axios.post(
       API_URL.DELHIVERY.B2B.LOGIN,
        {
          username: this.configService.get<string>('B2B_DELHIVERY_UN'),
          password: this.configService.get<string>('B2B_DELHIVERY_PS'),
        },
      );

      console.log('Login response:', response.data);

      // Check if the JWT is present in the response
      if (response.data.jwt) {
        this.token = response.data.jwt; // Store the JWT token in memory
        console.log('Token saved:', this.token);

        // Use the utility function to save the token
        saveToEnv('B2B_DELHIVERY_TOKEN', this.token);

        return this.token; // Return the token
      } else {
        console.error('Login was unsuccessful:', response.data);
        throw new Error('Login unsuccessful - token not received');
      }
    } catch (error) {
      console.error('Login failed:', error.message);
      throw error;
    }
  }

  // Schedule a task to login every 2 minutes
  
  // @Cron('*/2 * * * *')
  // async handleCron() {
  //   console.log('Scheduled task: attempting to login...');
  //   // await this.delhiveryLogin();
  // }

  // Function to get the current token
  getToken(): string | null {
    return this.token;
  }

}
