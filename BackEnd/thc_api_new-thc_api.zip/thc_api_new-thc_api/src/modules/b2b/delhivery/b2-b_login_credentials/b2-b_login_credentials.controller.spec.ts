import { Test, TestingModule } from '@nestjs/testing';
import { B2BLoginCredentialsController } from './b2-b_login_credentials.controller';

describe('B2BLoginCredentialsController', () => {
  let controller: B2BLoginCredentialsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [B2BLoginCredentialsController],
    }).compile();

    controller = module.get<B2BLoginCredentialsController>(B2BLoginCredentialsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
