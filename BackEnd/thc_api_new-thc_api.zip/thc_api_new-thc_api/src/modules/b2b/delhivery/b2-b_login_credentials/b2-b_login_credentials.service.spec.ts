import { Test, TestingModule } from '@nestjs/testing';
import { B2BLoginCredentialsService } from './b2-b_login_credentials.service';

describe('B2BLoginCredentialsService', () => {
  let service: B2BLoginCredentialsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [B2BLoginCredentialsService],
    }).compile();

    service = module.get<B2BLoginCredentialsService>(B2BLoginCredentialsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
