export class UpdateManifestDto {}
