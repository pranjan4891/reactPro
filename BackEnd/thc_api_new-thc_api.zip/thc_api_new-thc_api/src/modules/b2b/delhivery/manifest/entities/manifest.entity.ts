export class Manifest {}
