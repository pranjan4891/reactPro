export class CreateManifestDto {}
