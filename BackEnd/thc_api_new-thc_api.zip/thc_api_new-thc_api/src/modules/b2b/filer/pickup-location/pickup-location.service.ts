import { Injectable } from '@nestjs/common';
import { CreatePickupLocationDto } from './dto/create-pickup-location.dto';
import { UpdatePickupLocationDto } from './dto/update-pickup-location.dto';

@Injectable()
export class PickupLocationService {
  create(createPickupLocationDto: CreatePickupLocationDto) {
    return 'This action adds a new pickupLocation';
  }

  findAll() {
    return `This action returns all pickupLocation`;
  }

  findOne(id: number) {
    return `This action returns a #${id} pickupLocation`;
  }

  update(id: number, updatePickupLocationDto: UpdatePickupLocationDto) {
    return `This action updates a #${id} pickupLocation`;
  }

  remove(id: number) {
    return `This action removes a #${id} pickupLocation`;
  }
}
