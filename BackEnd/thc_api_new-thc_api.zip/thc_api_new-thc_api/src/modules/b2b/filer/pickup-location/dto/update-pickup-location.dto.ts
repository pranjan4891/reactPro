export class UpdatePickupLocationDto {}
