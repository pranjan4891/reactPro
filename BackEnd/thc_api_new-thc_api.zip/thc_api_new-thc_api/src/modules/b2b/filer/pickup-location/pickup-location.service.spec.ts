import { Test, TestingModule } from '@nestjs/testing';
import { PickupLocationService } from './pickup-location.service';

describe('PickupLocationService', () => {
  let service: PickupLocationService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PickupLocationService],
    }).compile();

    service = module.get<PickupLocationService>(PickupLocationService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
