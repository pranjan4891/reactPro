import { Module } from '@nestjs/common';
import { PickupLocationService } from './pickup-location.service';
import { PickupLocationController } from './pickup-location.controller';

@Module({
  controllers: [PickupLocationController],
  providers: [PickupLocationService],
})
export class PickupLocationModule {}
