import { Test, TestingModule } from '@nestjs/testing';
import { PickupLocationController } from './pickup-location.controller';
import { PickupLocationService } from './pickup-location.service';

describe('PickupLocationController', () => {
  let controller: PickupLocationController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PickupLocationController],
      providers: [PickupLocationService],
    }).compile();

    controller = module.get<PickupLocationController>(PickupLocationController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
