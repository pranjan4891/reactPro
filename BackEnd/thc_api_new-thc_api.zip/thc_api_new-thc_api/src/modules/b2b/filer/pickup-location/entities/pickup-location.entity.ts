export class PickupLocation {}
