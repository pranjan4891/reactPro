export class CreatePickupLocationDto {}
