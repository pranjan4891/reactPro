export class CreatePlanDto {}
