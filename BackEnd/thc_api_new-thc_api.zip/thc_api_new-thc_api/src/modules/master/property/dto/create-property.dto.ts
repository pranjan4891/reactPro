export class CreatePropertyDto {}
