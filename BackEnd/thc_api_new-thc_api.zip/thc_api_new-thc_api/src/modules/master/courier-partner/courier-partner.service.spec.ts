import { Test, TestingModule } from '@nestjs/testing';
import { CourierPartnerService } from './courier-partner.service';

describe('CourierPartnerService', () => {
  let service: CourierPartnerService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CourierPartnerService],
    }).compile();

    service = module.get<CourierPartnerService>(CourierPartnerService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
