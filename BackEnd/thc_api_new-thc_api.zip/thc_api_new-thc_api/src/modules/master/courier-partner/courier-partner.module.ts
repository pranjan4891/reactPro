import { Module } from '@nestjs/common';
import { CourierPartnerController } from './courier-partner.controller';
import { CourierPartnerService } from './courier-partner.service';
import { MongooseModule } from '@nestjs/mongoose';
import { CourierPartner, CourierPartnerSchema } from 'src/schemas/courier-partner.schema';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: CourierPartner.name, schema: CourierPartnerSchema }]),
  ],
  controllers: [CourierPartnerController],
  providers: [CourierPartnerService]
})
export class CourierPartnerModule {}
