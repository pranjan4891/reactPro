import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CourierPartner, CourierPartnerDocument } from '../../../schemas/courier-partner.schema';
import { createCourierPartnerDto } from './courier-partner.dto';

@Injectable()
export class CourierPartnerService {
    constructor(@InjectModel(CourierPartner.name) private courierPartnerModel: Model<CourierPartnerDocument> ) { }
    async getCourierPartners(courierPartner:createCourierPartnerDto){

        const { name, subtitle, logo } = courierPartner;

        const newCourierData = new this.courierPartnerModel({
            name,
            subtitle,
            logo,
        });
        

        const savedData = await newCourierData.save();
        return { savedData };

    }
}
