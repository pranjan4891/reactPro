import {
    IsString,
    IsNotEmpty,
  } from 'class-validator';

  export class createCourierPartnerDto{

    @IsString()
    @IsNotEmpty()
    name: string;
    
    @IsString()
    subtitle?: string;
    
    @IsString()
    @IsNotEmpty()
    logo: string;
  

  }
  