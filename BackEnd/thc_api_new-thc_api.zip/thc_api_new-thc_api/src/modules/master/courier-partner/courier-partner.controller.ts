import { Body, Controller, Get, Post } from '@nestjs/common';
import { CourierPartnerService } from './courier-partner.service';
import { createCourierPartnerDto } from './courier-partner.dto';

@Controller('courier-partner')
export class CourierPartnerController {
    constructor(private courierPartnerService: CourierPartnerService) { }

    @Post()
    // throwError() {
    //     throw new Error('This is a test internal server error');
    //   }

    async getCourierPartners(@Body() courierPartner: createCourierPartnerDto) {
        return await this.courierPartnerService.getCourierPartners(courierPartner);
    }

}
