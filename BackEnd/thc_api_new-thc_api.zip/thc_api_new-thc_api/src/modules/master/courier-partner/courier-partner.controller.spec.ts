import { Test, TestingModule } from '@nestjs/testing';
import { CourierPartnerController } from './courier-partner.controller';

describe('CourierPartnerController', () => {
  let controller: CourierPartnerController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CourierPartnerController],
    }).compile();

    controller = module.get<CourierPartnerController>(CourierPartnerController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
