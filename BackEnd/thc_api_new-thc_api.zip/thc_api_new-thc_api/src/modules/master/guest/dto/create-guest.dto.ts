export class CreateGuestDto {}
