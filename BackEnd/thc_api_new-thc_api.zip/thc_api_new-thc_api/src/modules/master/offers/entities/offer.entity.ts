export class Offer {}
