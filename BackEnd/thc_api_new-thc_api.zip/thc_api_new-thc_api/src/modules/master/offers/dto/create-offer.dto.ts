export class CreateOfferDto {}
