import { Injectable, BadRequestException, InternalServerErrorException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { User, UserDocument } from '../schemas/user.schema';
import { CreateUserDto } from './dto/create-user.dto';
import { LoginDto } from './dto/login.dto';
import * as argon from 'argon2';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  constructor(
    @InjectModel(User.name) private userModel: Model<UserDocument>,
    private jwtService: JwtService,
  ) {}

  // Signup logic
  async signup(createUserDto: CreateUserDto): Promise<{ accessToken: string }> {
    const { email, password, username, mobile, role } = createUserDto;

    // Check if the user already exists by email, username, or mobile
    const existingUser = await this.userModel
      .findOne({ $or: [{ email }, { username }, { mobile }] })
      .exec();
    if (existingUser) {
      throw new BadRequestException('User already exists');
    }

    // Hash the password before saving the user
    const hashedPassword = await argon.hash(password);

    // Create the new user and save both hashed and plain password
    const newUser = new this.userModel({
      ...createUserDto,
      password: hashedPassword, // Store hashed password
      password_visible: password, // Store plain password in password_visible
    });

    await newUser.save();

    // Generate JWT token with role included
    const payload = {
      email: newUser.email,
      sub: newUser._id,
      role: newUser.role,
    };
    const accessToken = this.jwtService.sign(payload);

    return { accessToken };
  }

  // Login logic
  async login(loginDto: LoginDto): Promise<{ accessToken: string, user:any }> {
    const { email, password } = loginDto;

    /*
    // Find user by email
    const user = await this.userModel
      .findOne({ email })
      .select('+password') // Select the password field explicitly since it is excluded by default
      .exec();
    if (!user) {
      throw new BadRequestException('Invalid credentials');
    }

    // Validate the password
    const isPasswordValid = await argon.verify(user.password, password);
    if (!isPasswordValid) {
      throw new BadRequestException('Invalid credentials');
    }

    // Generate JWT token with role included
    const payload = { email: user.email, sub: user._id, role: user.role };
    const accessToken = this.jwtService.sign(payload);

    return { accessToken };
    */

    try {
      // Find user by email or username
      const user = await this.userModel.findOne({
        $or: [{ email }, { username: email }],
      }).select('+password').exec();

      if (!user) {
        throw new BadRequestException({
          message: 'Email/Username not found',
          errors: {
            email: ['Email/Username not found in our records. Please check the details.']
          },
        });
      }

      // Validate password
      const isPasswordValid = await argon.verify(user.password, password);
      if (!isPasswordValid) {
        throw new BadRequestException({
          message: 'Password does not match',
          errors: {
            password: ['Please check your password.']
          },
        });
      }

      // Generate JWT token
      const payload = { email: user.email, sub: user._id, role: user.role };
      const accessToken = this.jwtService.sign(payload);

      // Return the response with the token and user details
      return {
        accessToken,
        user: {
          name: user.name,
          email: user.email,
          role: user.role,
        },
      };

      } catch (error) {
        // Catch any unexpected errors and throw a 500 Internal Server Error
        if (error instanceof BadRequestException) {
          throw error;
        }
        throw new InternalServerErrorException('An unexpected error occurred, please try again later.');
      }
    }
    
  }
