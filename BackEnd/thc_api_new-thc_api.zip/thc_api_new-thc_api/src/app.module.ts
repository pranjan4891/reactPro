import { MiddlewareConsumer, Module, RequestMethod } from '@nestjs/common';
import { AuthModule } from './auth/auth.module';
import { ConfigModule } from '@nestjs/config';
import { DatabaseModule } from './Mongoose/db.module';
import { UserModule } from './modules/user/user.module';
import { LoggerModule } from './logger/logger.module';
import { LoggerMiddleware } from './middleware/logger.middleware';
import { B2BLoginCredentialsModule } from './modules/b2b/delhivery/b2-b_login_credentials/b2-b_login_credentials.module';
import { ScheduleModule } from '@nestjs/schedule';
import { CourierPartnerModule } from './modules/master/courier-partner/courier-partner.module';
import { ManifestModule } from './modules/b2b/filer/manifest/manifest.module';
import { PickupLocationModule } from './modules/b2b/filer/pickup-location/pickup-location.module';
import { EmployeeModule } from './modules/employee/employee.module';
import { VenueModule } from './modules/master/venue/venue.module';
import { LocationModule } from './modules/master/location/location.module';
import { PropertyModule } from './modules/master/property/property.module';
import { PlanModule } from './modules/master/plan/plan.module';
import { OffersModule } from './modules/master/offers/offers.module';
import { GuestModule } from './modules/master/guest/guest.module';
@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    ScheduleModule.forRoot(),
    DatabaseModule,
    LoggerModule,
    AuthModule,
    UserModule,
    B2BLoginCredentialsModule,
    CourierPartnerModule,
    ManifestModule,
    PickupLocationModule,
    EmployeeModule,
    VenueModule,
    LocationModule,
    PropertyModule,
    PlanModule,
    OffersModule,
    GuestModule,
  ],
})
export class AppModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(LoggerMiddleware)
      .forRoutes({ path: '*', method: RequestMethod.ALL }); // Apply to all routes
  }
}
