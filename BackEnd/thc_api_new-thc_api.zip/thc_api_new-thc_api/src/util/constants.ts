
export const API_URL = {
    DELHIVERY: {
        B2B: {
            LOGIN:`https://btob-api-dev.delhivery.com/ums/login/`
        }
    }
}