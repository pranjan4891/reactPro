export interface JwtPayload {
  email: string;
  sub: string; // This is usually the user ID
  role: string; // Include the role if needed
}
