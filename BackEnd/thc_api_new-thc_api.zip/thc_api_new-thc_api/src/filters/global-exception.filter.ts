import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  InternalServerErrorException,
} from '@nestjs/common';
import { Response } from 'express';


@Catch()
export class GlobalExceptionFilter implements ExceptionFilter {
  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();

    // Default response values
    let statusCode = HttpStatus.INTERNAL_SERVER_ERROR;
    let errorCode = 'INTERNAL_SERVER_ERROR';
    let msg = this.getDefaultMessage(HttpStatus.INTERNAL_SERVER_ERROR); // Default message based on status code
    let remarks = 'RESPONSE_FAILED'; // Default remarks
    let exceptions: string | null = null; // Default to null if not provided
    let errors: any = null; // Default to null if not provided
    let data: any = null; // Default to null if data is not found

    // If it's an instance of HttpException, handle it with the correct logic
    if (exception instanceof HttpException) {
      statusCode = exception.getStatus();
      const exceptionResponse = exception.getResponse();

      // Handle the case where a custom response object is passed
      if (typeof exceptionResponse === 'object' && exceptionResponse !== null) {
        const {
          msg: customMsg,
          errorCode: customErrorCode,
          remarks: customRemarks,
          exceptions: customExceptions,
          errors: customErrors,
          data: customData, // Optional custom data
        } = exceptionResponse as any;

        // If msg is not provided, use the default message based on the status code
        msg = customMsg || this.getDefaultMessage(statusCode); // Custom message or default based on statusCode
        errorCode = customErrorCode || errorCode;
        remarks = customRemarks || remarks;
        exceptions = customExceptions || exceptions;
        errors = customErrors || errors;
        data = customData || null; // Default to null if no data is provided
      }
      // If the exception response is a string, handle it as a simple error message
      else if (typeof exceptionResponse === 'string') {
        exceptions = exceptionResponse;
        msg = exceptions || this.getDefaultMessage(statusCode); // Default msg for string exception
      }
    } else {
      // For other exceptions (non-HttpException), treat as generic error
      exceptions = 'Internal server error';
      msg = this.getDefaultMessage(HttpStatus.INTERNAL_SERVER_ERROR); // Default internal server error message
    }

    // Return the response with the formatted error message
    response.status(statusCode).json({
      statusCode,
      timestamp: new Date().toISOString(),
      msg,
      data, // Include data (if any) or null
      errorCode,
      exceptions,
      remarks,
      errors,
    });
  }

  // Helper method to get default messages based on status code
  private getDefaultMessage(statusCode: number): string {
    const messages: Record<number, string> = {
      [HttpStatus.BAD_REQUEST]: 'Bad Request',
      [HttpStatus.UNAUTHORIZED]: 'Unauthorized access', // Default message for 401 Unauthorized
      [HttpStatus.FORBIDDEN]: 'Forbidden',
      [HttpStatus.NOT_FOUND]: 'Resource not found',
      [HttpStatus.INTERNAL_SERVER_ERROR]: 'Internal Server Error',
      [HttpStatus.SERVICE_UNAVAILABLE]: 'Service Unavailable',
      [HttpStatus.GATEWAY_TIMEOUT]: 'Gateway Timeout',
      // Add more mappings for other status codes if needed
    };

    return messages[statusCode] || 'Error occurred'; // Default message if status code is not mapped
  }
}


