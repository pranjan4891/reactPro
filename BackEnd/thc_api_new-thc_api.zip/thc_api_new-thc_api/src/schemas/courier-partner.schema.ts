import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type CourierPartnerDocument = CourierPartner & Document;

@Schema({
  collection: 'timeshare_employees', // Automatically handle createdAt and updatedAt
  timestamps: true, // Automatically handle createdAt and updatedAt
})
export class CourierPartner {
  @Prop({ required: true })
  name: string;

  @Prop()
  subtitle: string; // 

  @Prop({ required: true})
  logo: string;

}

export const CourierPartnerSchema = SchemaFactory.createForClass(CourierPartner);
