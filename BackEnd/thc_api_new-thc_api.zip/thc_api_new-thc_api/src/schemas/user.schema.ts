import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { Role } from './role.enum'; // Enum for roles

export type UserDocument = User & Document;

@Schema({
  timestamps: true, // Automatically handle createdAt and updatedAt
})
export class User {
  @Prop({ required: true })
  name: string;

  @Prop({ required: true, unique: true })
  username: string;

  @Prop({ required: true, unique: true })
  email: string;

  @Prop({ required: true, unique: true })
  mobile: string;

  @Prop({ required: true, select: false })
  password: string;

  @Prop({ required: true,  select: false })
  password_visible: string;

  @Prop({ type: String, enum: Role, default: Role.USER }) // Enum for role, default USER
  role: Role;

  @Prop({ type: Number, default: 1 }) // 0=inactive, 1=active, 2=suspended
  status: number;
}

export const UserSchema = SchemaFactory.createForClass(User);
