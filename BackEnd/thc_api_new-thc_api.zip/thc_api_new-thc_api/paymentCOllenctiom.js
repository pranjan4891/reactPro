paymentCOllenctiom

userId , createdAt , paymentGateway , sataus: [Inition , PaymentDOne ,Payment/Suces] , data , id


transicions:[

    userId,
    transactionId: ,
    type: [Deposit , Withdrawal],
    amount: ,
    createdAt: ,
    data:{
        type:Deposit , paymentId: id
    },
    withdrawl:{
        orderId:[]
    }
    updatedAt: []
]



wallet:
{
    userId: ,
    walletBalance;,
    logId:[
        {typSwithDral}
    ]
    updatedAt:[]
}